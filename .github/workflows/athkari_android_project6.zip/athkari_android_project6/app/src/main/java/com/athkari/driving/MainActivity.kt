package com.athkari.driving

import android.annotation.SuppressLint
import android.content.Context
import android.media.AudioAttributes
import android.os.Build
import android.os.Bundle
import android.os.VibrationAttributes
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.view.HapticFeedbackConstants
import android.view.WindowManager
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private lateinit var webView: WebView

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // إبقاء الشاشة مضاءة أثناء القيادة
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        webView = WebView(this)
        webView.isHapticFeedbackEnabled = true
        setContentView(webView)

        val settings: WebSettings = webView.settings
        settings.javaScriptEnabled = true
        settings.domStorageEnabled = true
        settings.databaseEnabled = true
        settings.allowFileAccess = true
        settings.mediaPlaybackRequiresUserGesture = false
        settings.cacheMode = WebSettings.LOAD_DEFAULT

        webView.webViewClient = WebViewClient()
        webView.webChromeClient = WebChromeClient()
        webView.addJavascriptInterface(AndroidHapticsBridge(this), "AndroidHaptics")

        webView.loadUrl("file:///android_asset/index.html")

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                webView.evaluateJavascript(
                    "(function(){ if(document.getElementById('settingsModal') && !document.getElementById('settingsModal').classList.contains('hidden')){ closeSettingsModal(); return 'handled'; } if(document.getElementById('manageModal') && !document.getElementById('manageModal').classList.contains('hidden')){ closeManageModal(); return 'handled'; } if(state && state.activeCategory){ closeReaderToHome(); return 'handled'; } return 'exit'; })()"
                ) { result ->
                    if (result != null && result.contains("exit")) {
                        isEnabled = false
                        onBackPressedDispatcher.onBackPressed()
                    }
                }
            }
        })
    }

    inner class AndroidHapticsBridge(private val context: Context) {
        private fun getVibrator(): Vibrator {
            return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                val vm = context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as VibratorManager
                vm.defaultVibrator
            } else {
                @Suppress("DEPRECATION")
                context.getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
            }
        }

        // 5 مستويات لنبضة الاهتزاز (نبضة سريعة ولطيفة غير مزعجة)
        @JavascriptInterface
        fun vibratePulse(level: Int) {
            val clamped = level.coerceIn(1, 5)
            // مدة النبضة بالمللي ثانية (قصيرة جداً لتكون نبضة وليست رنيناً طويلاً)
            val durationMs = when (clamped) {
                1 -> 8L
                2 -> 12L
                3 -> 16L
                4 -> 22L
                else -> 28L
            }
            // شدة النبضة (1..255)
            val amplitude = when (clamped) {
                1 -> 42
                2 -> 78
                3 -> 118
                4 -> 170
                else -> 225
            }

            runOnUiThread {
                try {
                    val vibrator = getVibrator()
                    if (vibrator.hasVibrator()) {
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                            val attrs = VibrationAttributes.Builder()
                                .setUsage(VibrationAttributes.USAGE_ALARM)
                                .build()
                            vibrator.vibrate(VibrationEffect.createOneShot(durationMs, amplitude), attrs)
                        } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                            @Suppress("DEPRECATION")
                            val audioAttrs = AudioAttributes.Builder()
                                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                                .setUsage(AudioAttributes.USAGE_ALARM)
                                .build()
                            @Suppress("DEPRECATION")
                            vibrator.vibrate(VibrationEffect.createOneShot(durationMs, amplitude), audioAttrs)
                        } else {
                            @Suppress("DEPRECATION")
                            vibrator.vibrate(durationMs)
                        }
                    } else {
                        webView.performHapticFeedback(
                            HapticFeedbackConstants.CLOCK_TICK,
                            HapticFeedbackConstants.FLAG_IGNORE_GLOBAL_SETTING
                        )
                    }
                } catch (_: Exception) {
                }
            }
        }

        @JavascriptInterface
        fun vibrateStep() {
            vibratePulse(3)
        }

        @JavascriptInterface
        fun stopVibration() {
            runOnUiThread {
                try {
                    val vibrator = getVibrator()
                    vibrator.cancel()
                } catch (_: Exception) {
                }
            }
        }
    }
}
